// https://web-design-weekly.com/snippets/scroll-to-position-with-jquery/
// jquery function used to scroll to desired location on page
// 		opts.speed = milliseconds value for scrolling animation
// 		opts.offset = pixel value for top padding when scrolling
$.fn.scrollView = function (opts) {
	if (!opts) {
		opts = {};
	}
	if (!opts.speed) {
		opts.speed = 0;
	}
	if (!opts.offset) {
		opts.offset = 30;
	}
	return this.each(function () {
		$("html, body").animate({
			scrollTop : $(this).offset().top - opts.offset
		}, opts.speed);
	});
}

$(document).ready(function() {
	configureLogin();
	configureSearch();
	configureMenu();
	configureFormSubmit();
	configureUsabilityFeatures();
	configureThirdPartyLinks();
	
	function configureLogin() {
		$(".login-tog").click(function () {
			$("body").toggleClass("login-active");
			$("html").addClass("html-active");
		});
		
		$(".login-full-tog").click(function (event) {
			event.preventDefault();
			$("#loginSheet").slideDown();
			$(".login-full-tog").fadeIn();
			$("#header").scrollView();
		});
		
		$("#osType").val(navigator.platform);
		$("#osVersion").val(navigator.appVersion);
		$("#appDetail").val(navigator.userAgent);
		
		// used for determining if javascript is enabled for browser
		var cookieKeyValue = "nbo=" + escape(new Date());
		document.cookie = cookieKeyValue + ";expires=";
		$("#cookiesEnabled").val(document.cookie.indexOf(cookieKeyValue) != -1);
		document.cookie = cookieKeyValue + ";expires=Thu, 01-Jun-2006 23:59:59 GMT";
		
		$("#username").focus();
	}

	function configureSearch() {
		var button = $(".search-tog")[0];
		var elem = $("#searchSheet")[0];
		$(".search-tog-open").click(function (e) {
			$("body").toggleClass("search-active");
			e.preventDefault();
			$(".searchSheet").show();
			$("#searchSheet input[type='text']").focus();
			e.stopPropagation();
		});
		
		$(".searchSheet__toggle").click(function (e) {
			$("body").toggleClass("search-active");
			e.preventDefault();
			$(".searchSheet").hide();
			
			e.stopPropagation();
		});
		
		$(document).on("click", function (e) {
			if ($(e.target).closest(".searchSheet").length === 0) {
				$(".searchSheet").hide();
			}
		});
		$(document).on("keydown", function (e) {
			if (e.keyCode === 27) {
				// escape key
				$(".searchSheet").hide();
			}
		});
	}

	function configureMenu() {
		var $menu = $("#mob-menu").mmenu({
				// options
				"slidingSubmenus": false,
				"extensions": [
					"pagedim-black",
					"theme-dark"
				]
			}, {
				// configuration
				offCanvas: {
					pageSelector: "#base-area"
				},
				classNames: {
					fixedElements: {
						fixed: "hdr"
					}
				}
			});
		var $icon = $("#menu-icon");
		var API = $menu.data("mmenu");

		$icon.on("click", function () {
			API.open();
		});

		API.bind("opened", function () {
			setTimeout(function () {
				$icon.addClass("is-active");
			}, 100);
		});
		API.bind("closed", function () {
			setTimeout(function () {
				$icon.removeClass("is-active");
			}, 100);
		});
	}
	
	function configureUsabilityFeatures() {
		$("body").mousedown(function(e) {
			if (e.button == 1) {
				// middle click, disables viewing content overflow
				return false;
			}
		});
	}
	
	function configureThirdPartyLinks() {
		$("a[href*='myonlineinsurance.com'], a[href*='carvana.com'], a[href*='randolphbrooksfed.vlending.com'], a[href*='linkedin.com'], a[href*='rbfcu.mortgagewebcenter.com'], a[href*='petinsurance.com'],a[href*='rbfcu.cudlautosmart.com'],a[href*='randolphbrooksinsurance.consumerratequotes.com'],a[href*='rbrealty.com'],a[href*='salliemae.com'],a[href*='insuremyltc.com'],a[href*='deals.totalprotect.com'],a[href*='travelinsured.com'],a[href*='turbotax.intuit.com'],a[href*='itunes.apple.com'],a[href*='play.google.com'], a[href*='rbfcu.wd5.myworkdayjobs.com']").addClass("no-external");
		$("a").filter(function () {
			var ignoreLink =
				this.hostname == location.hostname || this.href.match(/^(mailto|tel|javascript)\:/);
			return !ignoreLink;
		}).addClass("externalanchor").attr("target", "_blank");
	}
	
	function configureFormSubmit() {
		$("form").submit(function (e) {
			$("input:visible").blur();
			$(this).find("input[type='submit']").replaceWith("<div id='spinloader' style='position:relative;'/> <span>Loading</span></div>");
			var target = document.getElementById("spinloader");
			var opts = {
				lines: 7,
				length: 0,
				width: 5,
				radius: 5,
				corners: 1,
				rotate: 0,
				direction: 1,
				color: "#000",
				speed: 1,
				trail: 60,
				shadow: false,
				hwaccel: false,
				className: "spinner",
				top: "6px",
				left: "50%"
			};
			new Spinner(opts).spin(target);
		});
	}
	
	(function(document, history, location) {
  var HISTORY_SUPPORT = !!(history && history.pushState);

  var anchorScrolls = {
    ANCHOR_REGEX: /^#[^ ]+$/,
    OFFSET_HEIGHT_PX: 50,

    /**
     * Establish events, and fix initial scroll position if a hash is provided.
     */
    init: function() {
      this.scrollToCurrent();
      window.addEventListener('hashchange', this.scrollToCurrent.bind(this));
      document.body.addEventListener('click', this.delegateAnchors.bind(this));
    },

    /**
     * Return the offset amount to deduct from the normal scroll position.
     * Modify as appropriate to allow for dynamic calculations
     */
    getFixedOffset: function() {
      return this.OFFSET_HEIGHT_PX;
    },

    /**
     * If the provided href is an anchor which resolves to an element on the
     * page, scroll to it.
     * @param  {String} href
     * @return {Boolean} - Was the href an anchor.
     */
    scrollIfAnchor: function(href, pushToHistory) {
      var match, rect, anchorOffset;

      if(!this.ANCHOR_REGEX.test(href)) {
        return false;
      }

      match = document.getElementById(href.slice(1));

      if(match) {
        rect = match.getBoundingClientRect();
        anchorOffset = window.pageYOffset + rect.top - this.getFixedOffset();
        window.scrollTo(window.pageXOffset, anchorOffset);

        // Add the state to history as-per normal anchor links
        if(HISTORY_SUPPORT && pushToHistory) {
          history.pushState({}, document.title, location.pathname + href);
        }
      }

      return !!match;
    },

    /**
     * Attempt to scroll to the current location's hash.
     */
    scrollToCurrent: function() {
      this.scrollIfAnchor(window.location.hash);
    },

    /**
     * If the click event's target was an anchor, fix the scroll position.
     */
    delegateAnchors: function(e) {
      var elem = e.target;

      if(
        elem.nodeName === 'A' &&
        this.scrollIfAnchor(elem.getAttribute('href'), true)
      ) {
        e.preventDefault();
      }
    }
  };

  window.addEventListener(
    'DOMContentLoaded', anchorScrolls.init.bind(anchorScrolls)
  );
})(window.document, window.history, window.location);
});