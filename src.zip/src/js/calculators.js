var lf_userResize = true;
var lf_currentIframe = '';

function lf_onResize(event) {
	lf_userResize = true;
}

function lf_onMessage(event) {
	var iFrame = document.getElementById(lf_currentIframe);
	if (null == iFrame || event.source != iFrame.contentWindow) {
		return;
	}
	var message = JSON.parse(event.data);
	var desiredHeight = message.height;
	iFrame.height = desiredHeight;
	lf_userResize = false;
}

$(document).ready(function() {
	$(".arrow-toggle-trigger").off("click.calulators").on("click.calulators", function (e) {
		e.preventDefault();
		var $me = $(this);
		var $frame = $me.next(".arrow-toggle-content").find("iframe");
		lf_currentIframe = $frame.attr("id");
		if ($frame.attr("src") != $frame.data("src")) {
			$frame.attr("src", $frame.data("src"));
		}
	});
	if (window.attachEvent) { //IE9, capability based.
		window.attachEvent('onmessage', lf_onMessage);
		window.attachEvent('onresize', lf_onResize);
	} else if (window.addEventListener) { // others, capability based.
		window.addEventListener('message', lf_onMessage, false);
		window.addEventListener('resize', lf_onResize, false);
	}
});