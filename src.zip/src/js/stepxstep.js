$(document).ready(function() {
	// don't reregister items in case of duplicate on page
	$(".stepxstep-tabs").not(".ui-tabs").tabs({
		event: "mouseover"
	});
});
