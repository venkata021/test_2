var rates = {};
//rates.baseurl = "https://echo.rbfcu.org/rate";
//rates.baseurl = "http://is-pc80.rbfcu.local:9080/rate";
rates.baseurl = "https://www.rbfcu.org/rate";

rates.grouploaded = false;
rates.productloaded = false;

rates.description = {};
rates.description.deposit = "See our rates for savings and checking accounts, money market accounts, and IRA accounts.";
rates.description.auto = "Drive a bargain when it comes to your vehicle. Your low-rate RBFCU loan can make it possible.";
rates.description.personal = "When you want to make a special purchase or cover an unexpected expense, an RBFCU personal loan gives you financial flexibility at an affordable rate.";
rates.description.cc = "Whether you like earning cash back on your purchases or benefiting from a low rate, we have an RBFCU credit card to fit your needs and lifestyle.";
rates.description.mortgage = "Whether you're buying, building, or refinancing a home, our competitive rates make the process easy.";
rates.description.home_equity = "Leverage the value of your home with a home equity loan or home equity line of credit (HELOC).";

rates.definition = {};
rates.definition.deposit = "Rates and terms are subject to change without prior notice; other restrictions may apply. Fees could reduce the earnings on the account. APY means Annual Percentage Yield. The dividend rate is the declared annual dividend rate paid on an account, which does not reflect compounding.";
rates.definition.auto_apr = "APR means Annual Percentage Rate. The specific rate and term will be dependent upon your credit rating, collateral value, amount financed, and other factors. Rates and terms are subject to change without prior notice; other restrictions may apply.";
rates.definition.personal_apr = "APR means Annual Percentage Rate. The specific rate will be dependent upon your credit rating and other factors. Rates and terms are subject to change without prior notice; other restrictions may apply.";
rates.definition.mortgage_apr = "APR means Annual Percentage Rate. Your final APR may vary based upon customary fees and closing costs which are treatable as interest when calculating your final APR. Rates and terms are subject to change without prior notice; other restrictions may apply. Mortgage lending is restricted to property in Texas. The payment example does not include amounts for taxes and insurance premiums. If applicable, the actual payment obligation will be greater. To view a payment estimate, use our <a href='https://calculators.rbfcu.org/response/lf-rbfcu/calc/home02'>mortgage payment calculator</a>.";
rates.definition.home_equity_apr = "APR means Annual Percentage Rate. The specific rate and term will be dependent upon your credit rating, collateral value, amount financed, and other factors. Rates and terms are subject to change without prior notice; other restrictions may apply. The payment example does not include amounts for taxes and insurance premiums, if applicable, and that the actual payment obligation will be greater. To view a payment estimate, use our <a href='https://calculators.rbfcu.org/response/lf-rbfcu/calc/creditline04'>loan payment calculator</a>.";

rates.disclosure = {};
rates.disclosure.certificate = "Early withdrawal penalty: 06 - 11 Month Certificate - 30 days; 12 - 23 Month Certificate - 60 days; 24 - 35 Month Certificate - 120 days; 36 - 47 Month Certificate - 180 days; 48 - 59 Month Certificate - 240 days; 60 - 71 Month Certificate - 300 days; 72 - 83 Month Certificate - 360 days; 84 Month Certificate - 420 days. The APY for certificates assumes dividends are added back to the certificate.";
rates.disclosure.construction = "At least 20 percent equity is required to secure a construction loan. Interim construction loan with terms up to 1 year are available. Accrued interest is payable with each draw. One time closes are available.";
rates.disclosure.vehicle = "Rates will be reduced by .20% for application submitted online.";

rates.disclosure.primary_mortgage = "Loans exceeding 90% Loan to Value will require Private Mortgage Insurance or a piggyback loan (90/5/5) and are subject to additional qualifications.";
rates.disclosure.secondary_mortgage = "10% equity required.";
rates.disclosure.land = "Loans exceeding 80% Loan to Value are priced 30 basis points higher and are subject to additional qualifications.";
rates.disclosure.rental = "20% equity required.";
rates.disclosure.improvement = "Equity requirements: 4 yr. 0%, 7 yr. 5%, 10 yr. 10%, 15 yr. 10% (minimum loan amount is $40,000).";
rates.disclosure.arm = "The Adjustable Rate Mortgages (ARM) begins with a low, fixed initial rate, for the first 5 years (60 months), and then can adjust upward or downward, every 60 months thereafter, starting with month 61. The initial rate can change every 5 years by no more than 3 percentage points up or down, never to exceed 5 percentage points above the initial rate. When the rate adjusts, your new rate will be the then current index plus margin, which is currently set at 2 percent for the new loans, as long as it does not exceed the 3 percent adjustment cap. Your rate will never increase more than 5% from the initial rate.";

rates.disclosure.home_equity = "At least 20 percent equity is required to secure a home equity loan. APR means Annual Percentage Rate. 30 year terms for Home Equity Loans are only offered as the first lien on the property. Generally, closing costs will be paid by the credit union; however, in some instances certain costs will be paid by the member. Hazard insurance is required. Minimum loan amount is $5,000. To view a payment estimate, use our <a href='https://calculators.rbfcu.org/response/lf-rbfcu/calc/creditline04'>loan payment calculator</a>.";
rates.disclosure.heloc = "The rate is based on an index minus a margin. The index is the Prime Rate as published in the Wall Street Journal (as of {{date}}, the variable rate is {{apr}} APR). The variable APR may increase or decrease quarterly, not to exceed an annual percentage rate of 15%. Rates and terms subject to change without notice; other restrictions may apply.<br /><br />Minimum Payment Requirements: Minimum monthly payment is calculated after each credit advance, based on your balance rounded up to the nearest $1,000.00. Your payment amount will remain the same unless you obtain another credit advance. We will recalculate your payment each time you obtain an advance. Ex: a HELOC with $50,000 balance will require a $700 payment at the time of the draw ($50,000 balance &divide; 1,000 = 50 x $14 = $700). To view a payment example, use our <a href='https://calculators.rbfcu.org/response/lf-rbfcu/calc/creditline04'>loan payment calculator</a>.";


(function() {
	// ------------------------------ rate groups
	$(document).ready(function () {
		var $items = $(".rate-group-holder .rate-content li[data-rate-config]");
		$items.each(function (index, elem) {
			var $elem = $(elem);
			var rateConfig = $elem.data("rate-config");
			if (!rateConfig) {
				return true; // continue to next element
			}
			if (rateConfig.productId) {
				var url = rates.baseurl + "/products/" + encodeURI(rateConfig.productId);
				$.get({
					url: url,
					dataType: "jsonp",
					success: function (response) {
						populateGroupItem($elem, rateConfig, response);
					}
				});
			}
		});
	});
	
	function populateGroupItem($rateElem, rateConfig, rateResponse) {
		var desiredTier = findTier(rateConfig, rateResponse);
		if (!desiredTier) {
			return;
		}
		var $nameDesc = $rateElem.find(".name-desc");
		var $valueDesc = $rateElem.find(".value-desc");
		var rate = null;
		if (rateResponse.groupId == "DEP") {
			$nameDesc.text("as high as");
			$valueDesc.text("APY");
			rate = desiredTier.maxAnnualRate;
		} else {
			$nameDesc.text("as low as");
			$valueDesc.text("APR");
			if (isConsumerRate(rateResponse.groupId)) {
				rate = desiredTier.minRate;
			} else {
				rate = desiredTier.minAnnualRate;
			}
		}
		$rateElem.find(".rate-value").text(rate);
	}
	
	function isConsumerRate(groupId) {
		return "AUTO" == groupId || "PERS" == groupId || "CC" == groupId;
	}
	
	// ------------------------------ individual rate boxes
	$(document).ready(function () {
		var $items = $(".rate[data-rate-config]");
		$items.each(function (index, elem) {
			var $elem = $(elem);
			var rateConfig = $elem.data("rate-config");
			if (!rateConfig) {
				return true; // continue to next element
			}
			if (rateConfig.productId) {
				// TODO call API with all products at once
				var url = rates.baseurl + "/products/" + encodeURI(rateConfig.productId);
				$.get({
					url: url,
					dataType: "jsonp",
					success: function (response) {
						populateIndividual($elem, rateConfig, response);
					}
				});
			}
		});
	});
	
	function populateIndividual($rateElem, rateConfig, rateResponse) {
		var desiredTier = findTier(rateConfig, rateResponse);
		if (!desiredTier) {
			return;
		}
		if (rateResponse.groupId == "DEP") {
			populatePrimary($rateElem, desiredTier.minAnnualRate, "apy");
		} else if (isConsumerRate(rateResponse.groupId)) {
			$rateElem.find(".pretext").text("as low as");
			populatePrimary($rateElem, desiredTier.minRate, "apr");
			if (desiredTier.monthsDuration) {
				// some consumer lending products don't have a duration (credit card)
				populateSecondary($rateElem, desiredTier.monthsDuration + " months", "term");
			} else if (rateResponse.name && rateResponse.name.toLowerCase().indexOf("credit card") > -1) {
				populateSecondary($rateElem, "Credit Card", "type");
			}
		} else if (rateResponse.groupId == "MOR") {
			populatePrimary($rateElem, desiredTier.minAnnualRate, "apr");
			populateSecondary($rateElem, desiredTier.minRate, "rate");
		} else if (rateResponse.groupId == "HOM") {
			if (rateResponse.id == "HELOC") {
				populatePrimary($rateElem, desiredTier.minRate, "apr");
				$rateElem.find(".pretext").text("as low as");
			} else {
				populatePrimary($rateElem, desiredTier.minAnnualRate, "apr");
				var years = getYearText(desiredTier.monthsDuration);
				populateSecondary($rateElem, years, "term");
			}
		}
		
		// update rate link to jump directly to desired group/product
		var $link = $rateElem.find(".rate__detaillink a");
		$link.attr("href", $link.attr("href") + "#" + rateResponse.groupId + "-" + rateResponse.id);
	}
	
	function findTier(rateConfig, rateResponse) {
		try {
			if (!rateResponse || !rateResponse.tiers || !rateResponse.tiers.length) {
				return null;
			}
			if (rateConfig.tierCalc) {
				// DOM is configured to look for specific tier
				var calcs = rateConfig.tierCalc.split(";");
				for (var i = 0; i < rateResponse.tiers.length; i++) {
					var tier = rateResponse.tiers[i];
					if (tierMatchesRequirements(tier, calcs)) {
						return tier;
					}
				}
			}
			return rateResponse.tiers[0];
		} catch (err) {
		}
		return null;
	}
	
	function populatePrimary($elem, value, description) {
		populateByIndex($elem, value, description, 0);
	}
	
	function populateSecondary($elem, value, description) {
		populateByIndex($elem, value, description, 1);
	}
	
	function populateByIndex($elem, value, description, index) {
		var $container = $elem.find(".rate__entry").eq(index);
		var $value = $container.find(".value");
		$value.text(value);
		if ($.isNumeric(value)) {
			$value.parent().addClass("percentage");
		}
		$container.find(".description").text(description);
	}
	
	function tierMatchesRequirements(tier, requirements) {
		// requirements = array of name=value, where name is the property name on the tier object and value is what that property's value should be
		// 		if all requirements are met, the tier is a match
		for (var i = 0; i < requirements.length; i++) {
			var parts = requirements[i].split("=");
			var propName = parts[0];
			var propVal = parts[1];
			if (tier[propName] != propVal) { // if propName == xxx, tier[propName] is same as JSON tier.xxx
				return false;
			}
		}
		return true;
	}
	
	
	// ------------------------------ rates homepage
	$(document).ready(function () {
		var $items = $(".rate-detail-holder[data-rate-config]");
		$items.each(function (index, elem) {
			var $elem = $(elem);
			var rateConfig = $elem.data("rate-config");
			if (typeof rateConfig === "string") {
				// HTML output had attribute value with single quotes, not double; jquery .data() requires double quotes
				var json = $elem.attr("data-rate-config").replace(/'/g, '"');
				rateConfig = $.parseJSON(json);
			}
			if (!rateConfig) {
				return true; // continue to next element
			}
			if (rateConfig.groupId) {
				var url = rates.baseurl + "/groups/" + encodeURI(rateConfig.groupId);
				$.get({
					url: url,
					dataType: "jsonp",
					success: function (response) {
						populateHomepage($elem, response);
					}
				});
			}
		});
		
		setTimeout(function() {
			openDesiredRateGroup();
		}, 500);
	});
	
	function populateHomepage($rateElem, rateResponse) {
		if (!rateResponse || !rateResponse.products || !rateResponse.products.length) {
			return;
		}
		var $productShell = $rateElem.find(".rate-products-holder li");
		
		var $productContainer = $("<ul></ul>"); // used so DOM is only updated once at end
		for (var i = 0; i < rateResponse.products.length; i++) {
			$productContainer.append($productShell.clone());
		}
		var $productContainers = $productContainer.children();
		$.each(rateResponse.products, function (index) {
			var $elem = $productContainers.eq(index); // <li> element
			var productResponse = rateResponse.products[index];
			var groupId = productResponse.groupId;
			var productId = productResponse.id;
			
			$elem.attr("id", productId);
			$elem.find(".title").html(productResponse.name);
			
			var $table = $elem.find(".rwd-table");
			if (groupId == "DEP") {
				
				if (productId == "SAV" || productId == "CHE") {
					var headers = [ "Minimum Opening Balance", "Dividend Rate", "APY" ];
					setTableHeaders($table, headers);
					var tier = productResponse.tiers[0];
					addTableRow($table, headers, [ getDollarDisplay(tier.minAmount), tier.minRate + "%", tier.minAnnualRate + "%" ]);
				} else if (productId == "CER" || productId == "BUS") {
					var headers = [ "Months", "Amount", "Dividend Rate", "APY" ];
					setTableHeaders($table, headers);
					var numSubTiers = getNumberOfSubTiers(productResponse.tiers, "monthsDuration");
					var itemsPerSubTier = productResponse.tiers.length / numSubTiers; // it's important to note that this assumes each subtier has the same number of elements
					for (var i = 0; i < productResponse.tiers.length; i++) {
						var tier = productResponse.tiers[i];
						var firstInSubTier = (i % itemsPerSubTier) == 0;
						var lastInSubTier = ((i + 1) % itemsPerSubTier) == 0;
						var monthHeader = firstInSubTier ? tier.monthsDuration : "";
						var amountRange = getAmountRange(tier.minAmount, tier.maxAmount, lastInSubTier)
						addTableRow($table, headers, [ monthHeader, amountRange, tier.minRate + "%", tier.minAnnualRate + "%" ]);
					}
					
					if (productId == "CER") {
						setProductDisclosure($elem, rates.disclosure.certificate);
					}
				} else {
					var headers = [ "Amount", "Dividend Rate", "APY" ];
					setTableHeaders($table, headers);
					for (var i = 0; i < productResponse.tiers.length; i++) {
						var tier = productResponse.tiers[i];
						var lastInTier = i == (productResponse.tiers.length - 1);
						var amountRange = getAmountRange(tier.minAmount, tier.maxAmount, lastInTier)
						addTableRow($table, headers, [ amountRange, tier.minRate + "%", tier.minAnnualRate + "%" ]);
					}
					if (productId == "MON") {
						setProductDisclosure($elem, "A " + getDollarDisplay(productResponse.tiers[0].minAmount) + " minimum balance is required to open a money market account.");
					}
				}
				
				setGroupAsOf($rateElem, "Annual Percentage Yield");
				setGroupDescription($rateElem, rates.description.deposit);
				setGroupDisclosure($rateElem, rates.definition.deposit);
			} else if (isConsumerRate(groupId)) {
				var headers = [ "Months", "Rate (APR)", "Payment per $1,000" ];
				var showOnlyApr = $.inArray(productId, [ "LOC", "PREMCC", "CASHCC" ]) > -1;
				if (showOnlyApr) {
					headers = [ "Rate (APR)" ]; // just APR for loc and credit cards
				} else if (productId == "COLLAT") {
					headers = [ "APR (as low as)" ];
				} else if (productId == "SIG") {
					headers[headers.length - 1] = "Payment per $100";
				}
				setTableHeaders($table, headers);
				var rows = [];
				for (var i = 0; i < productResponse.tiers.length; i++) {
					var tier = productResponse.tiers[i];
					var rateRange = tier.minRate + "% - " + tier.maxRate + "%";
					var paymentRange = getPreciseAmountRange(tier.minAmount, tier.maxAmount);
					if (showOnlyApr) {
						rows.push([ rateRange ]);
					} else if (productId == "COLLAT") {
						rows.push([ tier.minRate + "%" ]);
					} else {
						rows.push([ tier.monthsDuration, rateRange, paymentRange ]);
					}
				}
				$.each(rows, function (y, row) {
					addTableRow($table, headers, row);
				});
				
				if (productId == "VEHICLE") {
					setProductDisclosure($elem, rates.disclosure.vehicle);
				}
				
				setGroupAsOf($rateElem, "Annual Percentage Rate");
				if (groupId == "AUTO") {
					setGroupDisclosure($rateElem, rates.definition.auto_apr);
					setGroupDescription($rateElem, rates.description.auto);
				} else if (groupId == "PERS") {
					setGroupDisclosure($rateElem, rates.definition.personal_apr);
					setGroupDescription($rateElem, rates.description.personal);
				} else if (groupId == "CC") {
					setGroupDisclosure($rateElem, rates.definition.personal_apr);
					setGroupDescription($rateElem, rates.description.cc);
				}
			} else if (groupId == "MOR") {
				var headers = [ "Term", "Rate (as low as)", "APR (as low as)", "Payment per $10,000" ];
				if (productId == "ARM") {
					headers = [ "Rate (as low as)", "APR (as low as)" ];
				} else if (productId == "CONSTRUCT") {
					headers = [ "Term", "APR (as low as)" ];
				}
				setTableHeaders($table, headers);
				for (var i = 0; i < productResponse.tiers.length; i++) {
					var tier = productResponse.tiers[i];
					var rateRange = tier.minRate + "%";
					var aprRange = tier.minAnnualRate + "%";
					var years = getYearText(tier.monthsDuration);
					if (productId == "ARM") {
						addTableRow($table, headers, [ rateRange, aprRange ]);
					} else if (productId == "CONSTRUCT") {
						addTableRow($table, headers, [ years, rateRange ]);
					} else {
						var paymentRange = getDollarDisplay(tier.minAmount, true);
						addTableRow($table, headers, [ years, rateRange, aprRange, paymentRange ]);
					}
				}
				
				if (productId == "CONSTRUCT") {
					setProductDisclosure($elem, rates.disclosure.construction);
				} else if (productId == "PRI") {
					setProductDisclosure($elem, rates.disclosure.primary_mortgage);
				} else if (productId == "SEC") {
					setProductDisclosure($elem, rates.disclosure.secondary_mortgage);
				} else if (productId == "LAND") {
					setProductDisclosure($elem, rates.disclosure.land);
				} else if (productId == "RENT") {
					setProductDisclosure($elem, rates.disclosure.rental);
				} else if (productId == "IMPROVE") {
					setProductDisclosure($elem, rates.disclosure.improvement);
				} else if (productId == "ARM") {
					setProductDisclosure($elem, rates.disclosure.arm);
				}
				
				setGroupAsOf($rateElem, "Annual Percentage Rate");
				setGroupDescription($rateElem, rates.description.mortgage);
				setGroupDisclosure($rateElem, rates.definition.mortgage_apr);
			} else if (groupId == "HOM") {
				var headers = [ "Term", "Rate/APR (as low as)", "Payment per $10,000" ];
				if (productId == "HELOC") {
					headers = [ "Rate/APR (as low as)" ];
				}
				setTableHeaders($table, headers);
				for (var i = 0; i < productResponse.tiers.length; i++) {
					var tier = productResponse.tiers[i];
					var row = [];
					if (productId == "HELOC") {
						row = [ tier.minRate + "%" ];
					} else {
						var paymentRange = getDollarDisplay(tier.minAmount, true);
						row = [ getYearText(tier.monthsDuration), tier.minAnnualRate + "%", paymentRange ];
					}
					addTableRow($table, headers, row);
				}
				
				if (productId == "HOMEEQUITY") {
					setProductDisclosure($elem, rates.disclosure.home_equity);
				} else if (productId == "HELOC") {
					var heloc_disclosure = rates.disclosure.heloc.replace("{{apr}}", aprRange).replace("{{date}}", getCurrentDate());
					setProductDisclosure($elem, heloc_disclosure);
				}
				
				setGroupAsOf($rateElem, "Annual Percentage Rate");
				setGroupDescription($rateElem, rates.description.home_equity);
				setGroupDisclosure($rateElem, rates.definition.home_equity_apr);
			}
		});
		
		$rateElem.find(".curr-date").text(getCurrentDate());
		
		$rateElem.find(".rate-products-holder").empty().append($productContainers);
		registerArrowToggle(); // reregister toggle expand/collapse for products
		
		openDesiredRateProduct();
		
		configureTabChangeEvent();
	}
	
	function getYearText(numMonths) {
		var years = numMonths / 12;
		var suffix = (years > 1 ? " years" : " year");
		return years + suffix;
	}
	
	function getPreciseAmountRange(minValue, maxValue) {
		return getDollarDisplay(minValue, true) + " - " + getDollarDisplay(maxValue, true);
	}
	
	function getAmountRange(minValue, maxValue, lastInTier) {
		var amountRange = null;
		if (lastInTier) {
			amountRange = getDollarDisplay(minValue) + "+";
		} else {
			amountRange = getDollarDisplay(minValue) + " - " + getDollarDisplay(maxValue);
		}
		return amountRange;
	}
	
	function getDollarDisplay(value, showPreciseValue) {
		// see http://stackoverflow.com/a/2901298/1880761
		if (value) {
			var parts = value.toString().split(".");
			parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
			if (showPreciseValue) {
				return "$" + parts.join(".");
			} else {
				return "$" + parts[0]; // dropping the decimal values
			}
		}
		return "";
	}
	
	function getNumberOfSubTiers(tiers, distinguishingPropName) {
		var subTierIds = [];
		$.each(tiers, function (index, tier) {
			var tierId = tier[distinguishingPropName];
			if ($.inArray(tierId, subTierIds) < 0) {
				subTierIds.push(tierId);
			}
		});
		return subTierIds.length;
	}
	
	function setTableHeaders($table, headerTitles) {
		var $row = $("<tr></tr>");
		for (var i = 0; i < headerTitles.length; i++) {
			$row.append($("<th>" + headerTitles[i] + "</th>"));
		}
		$table.find("thead").append($row);
	}
	
	function addTableRow($table, headerTitles, values) {
		var $row = $("<tr></tr>");
		for (var i = 0; i < values.length; i++) {
			var title = headerTitles[i];
			var value = values[i];
			if (!value) {
				value = "";
			}
			$row.append($("<td data-th='" + title + "'>" + value + "</td>"));
		}
		$table.find("tbody").append($row);
	}
	
	// http://stackoverflow.com/a/3067896/1880761
	Date.prototype.mmddyyyy = function() {
		var mm = this.getMonth() + 1; // getMonth() is zero-based
		var dd = this.getDate();

		return [(mm > 9 ? '' : '0') + mm,
					(dd > 9 ? '' : '0') + dd,
					this.getFullYear()
				].join('-');
	};
	
	function getCurrentDate() {
		var date = new Date();
		return date.mmddyyyy();
	}
	
	function setProductDisclosure($productElem, text) {
		$productElem.find(".product-disclosure").html(text);
	}
	function setGroupAsOf($rateElem, text) {
		$rateElem.find(".group-as-of").text(text);
	}
	function setGroupDescription($rateElem, text) {
		$rateElem.find(".group-description").text(text);
	}
	function setGroupDisclosure($rateElem, text) {
		$rateElem.find(".group-disclosure").html(text);
	}
	
	function openDesiredRateGroup() {
		if (!rates.grouploaded) {
			var values = getRatePageLoadValues();
			if (values) {
				var groupId = values[0];
				var $container = $(".rates-homepage-cntr");
				var $tabs = $container.find("[role=tab]");
				var $tab = $tabs.filter("#" + groupId);
				if ($tab.length) {
					$tab.trigger("click", $tab); // open group tab
					var headerOffset = $(".thinTopCntr").height() + $(".mainHeaderCntr").height() + $(".lowerBarCntr").height() + 10; // 10 for padding
					$container.scrollView({ speed: 150, offset: headerOffset}); //issue with header overlay
					rates.grouploaded = true;
				}
			}
		}
	}
	
	function openDesiredRateProduct() {
		if (!rates.productloaded) {
			var values = getRatePageLoadValues();
			if (values && values.length > 1) {
				var productId = values[1];
				var $elem = $("#" + productId);
				if ($elem.length) {
					$elem.find("a.title").click();
					rates.productloaded = true;
				}
			}
		}
	}
	
	function getRatePageLoadValues() {
		/* values go in order of specificity: groupid-productid
			following are valid hashes:
							: empty/none, nothing will be opened on page load
				#CON		: will open consumer tab
				#CON-ATV	: will open consumer tab and then ATV group
		*/
		if (window.location.hash) {
			// replace # which is first character in hash value, then split out values
			return window.location.hash.substring(1).split("-");
		}
		return null;
	}
	
	function configureTabChangeEvent() {
		/*
		var $tabs = $(".rates-homepage-cntr").find("[role=tab]");
		$tabs.off("tabactivate").on("tabactivate", function (e, newTab) {
			var $tab = $(newTab);
			var currHash = window.location.hash;
			if (currHash) {
				// TODO, both on tab change event and on rate group open (.arrow-toggle-trigger)
			}
		});
		*/
	}
})();
