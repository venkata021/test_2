(function() {
	$(document).ready(function () {
		$("[data-modal-url]").click(function (ev) {
			var $me = $(this);
			var modalUrl = $me.data("modal-url"); // populated by Sitefinity
			if (modalUrl) {
				ev.preventDefault();
				var $modal = $("#page-modal");
				if (!$modal.length) {
					// create modal container and append to DOM
					$modal = $('<div id="page-modal" class="modal"></div>').insertAfter("#content-body");
				}
				
				$modal.empty();
				
				var $container = $("<div></div>");
				
				$container.load(modalUrl, function () {
					$modal.html($(this).find("#fragment-body").html());
					$modal.show();
					
					$(".modal__close").click(function () {
						$modal.hide();
					});
				});
				
				$container.remove(); // clean up
				
				$(window).click(function (e) {
					if (e.target == $modal.get(0)) {
						$modal.hide();
					}
				});
			}
		});
	});
})();
